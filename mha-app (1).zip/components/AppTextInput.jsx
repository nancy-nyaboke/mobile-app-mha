import {useState} from "react";
import {StyleSheet, TextInput,} from "react-native";
import {COLORS, SIZES} from "../constants";


const AppTextInput = ({onChangeText, multiline, numberOfLines, ...otherProps}) => {
    const [focused, setFocused] = useState(false);

    return (
        <TextInput
            onFocus={() => setFocused(true)}
            onBlur={() => setFocused(false)}
            onChangeText={onChangeText}
            placeholderTextColor={COLORS.accent200}
            multiline={multiline}
            numberOfLines={numberOfLines}
            style={[
                {
                    fontSize: SIZES.medium,
                    padding: SIZES.large,
                    backgroundColor: COLORS.bg200,
                    borderRadius: SIZES.small,
                    marginVertical: SIZES.small,
                },
                focused && {
                    borderWidth: 3,
                    borderColor: COLORS.bluish2,
                    shadowOffset: {width: 4, height: SIZES.small},
                    shadowColor: COLORS.primary100,
                    shadowOpacity: 0.2,
                    shadowRadius: SIZES.small,
                },
            ]}
            {...otherProps}
        />
    );
};

export default AppTextInput;

const styles = StyleSheet.create({});
