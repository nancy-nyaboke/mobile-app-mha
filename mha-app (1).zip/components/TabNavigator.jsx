import {createBottomTabNavigator} from "@react-navigation/bottom-tabs";
import Ionicons from "@expo/vector-icons/Ionicons";

import {COLORS, SIZES} from "../constants";
import Home from "../screens/Home";
import Profile from "../screens/Profile";
import HealthRecords from "../screens/records/HealthRecords";
import CommunicationHub from "../screens/CommunicationHub";
import {useEffect, useState} from "react";
import {getUserInfo} from "../utils/utils";

const Tab = createBottomTabNavigator();

const TabNavigator = ({navigation, route}) => {
    const [role, setRole] = useState(null)
    const {setUserToken} = route.params

    useEffect( () => {
        getUserInfo().then((data) => {
            if (data) {
                setRole(data.role)
            }
        })
    }, []);


    return (
        <Tab.Navigator
            screenOptions={
            ({route}) => ({
                tabBarIcon: ({focused, color, size}) => {
                    let iconName;

                    switch (route.name) {
                        case 'Home':
                            iconName = focused ? 'home' : 'home-outline';
                            break;
                        case 'Chat':
                            iconName = focused ? 'chatbubble' : 'chatbubble-outline';
                            break;
                        case 'Records':
                            iconName = focused ? 'document-text' : 'document-text-outline';
                            break;
                        case 'Profile':
                            iconName = focused ? 'person' : 'person-outline';
                            break;
                    }

                    return <Ionicons name={iconName} size={SIZES.xxLarge} color={color}/>;
                },
                tabBarActiveTintColor: COLORS.primary100,
                tabBarInactiveTintColor: COLORS.gray,
                headerShown: false,
            })
        }
        >
            <Tab.Screen name="Home" component={Home} />
            <Tab.Screen name="Chat" component={CommunicationHub} />
            {role === 'doctor' && <Tab.Screen name="Records" component={HealthRecords} />}
            <Tab.Screen name="Profile" component={Profile} initialParams={{setUserToken}}/>
        </Tab.Navigator>
    );
};

export default TabNavigator;
