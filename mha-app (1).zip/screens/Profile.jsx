import {Button, StyleSheet, Text, View} from 'react-native';
import AsyncStorage from "@react-native-async-storage/async-storage";

const Profile = ({navigation, route}) => {
    const {setUserToken} = route.params;

    const handleLogout = async () => {
        const keys = ['userInfo'];
        await AsyncStorage.multiRemove(keys);
        setUserToken(null);
    }

    return (
        <View style={styles.container}>
            <Text>Me</Text>

            <Button title={'Logout'} onPress={handleLogout}/>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
});

export default Profile;
