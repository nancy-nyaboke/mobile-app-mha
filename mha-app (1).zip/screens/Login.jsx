import { useState } from "react";
import {
  ActivityIndicator,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { COLORS, SIZES } from "../constants";
import AppTextInput from "../components/AppTextInput";
import { decodeUserInfo } from "../utils/utils";
import { API_URL } from "@env";

const Login = ({ navigation, route }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const { setUserToken } = route.params;

  const handleLogin = async () => {
    setError(null);

    if (email === "" || password === "") {
      setError("Please fill all fields");
      return;
    }

    setIsLoading(true);
    try {
      console.log(API_URL);
      // const response = await fetch(`${API_URL}/login`, {
      const response = await fetch(
        `https://mha-server-latest.onrender.com/login`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email,
            password,
          }),
        }
      );

      const data = await response.json();

      if (response.ok) {
        setIsLoading(false);
        setUserToken(data.accessToken);
        const decodedData = await decodeUserInfo(data.accessToken);
        await AsyncStorage.setItem("userInfo", JSON.stringify(decodedData));
      } else {
        setError("Invalid email or password");
        setIsLoading(false);
      }
    } catch (error) {
      console.log(error);
      setError(error.message);
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView>
      <View style={styles.container}>
        <View
          style={{
            alignItems: "center",
          }}
        >
          <Text
            style={{
              padding: SIZES.large,
              fontSize: SIZES.xxLarge,
              color: COLORS.primary100,
              fontWeight: "bold",
            }}
          >
            Login Here
          </Text>

          <Text
            style={{
              fontSize: SIZES.large,
              maxWidth: "60%",
              textAlign: "center",
            }}
          >
            Welcome back. We missed you!
          </Text>
        </View>

        <View
          style={{
            padding: 2,
            marginTop: 40,
          }}
        >
          <AppTextInput
            value={email}
            onChangeText={setEmail}
            placeholder="Email"
          />
          <AppTextInput
            value={password}
            onChangeText={setPassword}
            placeholder="Password"
            secureTextEntry={true}
          />
        </View>

        {error && (
          <Text
            style={{
              color: "red",
              textAlign: "center",
              fontSize: SIZES.medium,
              marginVertical: SIZES.small,
            }}
          >
            {error}
          </Text>
        )}

        <TouchableOpacity
          style={{
            padding: SIZES.large,
            backgroundColor: COLORS.primary100,
            marginVertical: SIZES.small * 3,
            borderRadius: SIZES.small,
            shadowColor: COLORS.primary100,
            shadowOffset: {
              width: 0,
              height: SIZES.small,
            },
            shadowOpacity: 0.3,
            shadowRadius: SIZES.small,
          }}
          onPress={handleLogin}
        >
          <Text
            style={{
              color: "white",
              textAlign: "center",
              fontSize: SIZES.large,
            }}
          >
            {isLoading ? <ActivityIndicator size={"large"} /> : "Login"}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navigation.navigate("Register")}
          style={{
            padding: SIZES.small,
          }}
        >
          <Text
            style={{
              color: COLORS.text100,
              textAlign: "center",
              fontSize: SIZES.medium,
            }}
          >
            Create new account
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    display: "flex",
    backgroundColor: "#fff",
    height: "100%",
    padding: 20,
  },
  input: {
    height: 40,
    width: "100%",
    margin: 12,
    borderRadius: 12,
    borderWidth: 1,
    padding: 10,
  },
});

export default Login;
