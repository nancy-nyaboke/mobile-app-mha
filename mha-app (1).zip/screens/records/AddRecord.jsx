import React, {useState} from 'react';
import {View, Text, TextInput, Button, StyleSheet, Alert, ActivityIndicator, SafeAreaView} from 'react-native';
import AppTextInput from "../../components/AppTextInput";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {API_URL} from "@env";

const AddRecord = () => {
    const [title, setTitle] = useState('');
    const [type, setType] = useState('');
    const [description, setDescription] = useState('');
    const [notes, setNotes] = useState('');
    const [isLoading, setIsLoading] = useState(false)

    const handleSubmit = async () => {
        if (!title || !type || !description) {
            Alert.alert('Error', 'Please fill in all required fields');
            return
        }

        setIsLoading(true)
        try {
            const token = await AsyncStorage.getItem('userToken')
            // const response = await fetch(`${API_URL}/add-record`, {
            const response = await fetch(
                    `https://mha-server-latest.onrender.com/add-record`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + token
                },
                body: JSON.stringify({
                    title,
                    type,
                    description,
                    notes
                }),
            });

            const data = await response.json()

            setIsLoading(false)
            if (response.ok) {
                Alert.alert('Success', 'record added successfully')
                setTitle('')
                setType('')
                setDescription('')
                setNotes('')
            } else {
                Alert.alert('Error occured', data.message)
            }

        } catch (error) {
            Alert.alert('Error', error.message)
            setIsLoading(false)
        }

    };

    return (
        <SafeAreaView style={styles.container}>
            <View>
                <Text style={styles.title}>Add a New Health Record</Text>
                <AppTextInput
                    value={title}
                    onChangeText={setTitle}
                    placeholder="Title"
                />

                <AppTextInput
                    value={type}
                    onChangeText={setType}
                    placeholder="Type"
                />

                <AppTextInput
                    value={description}
                    onChangeText={setDescription}
                    placeholder="Description"
                    multiline
                    numberOfLines={5}
                />

                <AppTextInput
                    placeholder="Notes (optional)"
                    value={notes}
                    onChangeText={setNotes}
                />

                {isLoading ?
                    <ActivityIndicator size={"large"}/> :
                    <Button title="Submit" onPress={handleSubmit}/>
                }
            </View>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        padding: 20,
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        // color: 'green',
        marginBottom: 20,
    },
    input: {
        height: 40,
        borderColor: 'gray',
        borderWidth: 1,
        marginBottom: 20,
        padding: 10,
    },
});

export default AddRecord;
