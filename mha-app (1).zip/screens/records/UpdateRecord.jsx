import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { COLORS, SHADOWS, SIZES } from "../../constants";
import AppTextInput from "../../components/AppTextInput";
import { LinearGradient } from "expo-linear-gradient";
import { API_URL } from "@env";

function UpdateRecord({ navigation, route }) {
  const [isLoading, setIsLoading] = useState(false);
  const [record, setRecord] = useState("");
  const { recordId } = route.params;

  // fetch record details
  const fetchRecord = async () => {
    try {
      setIsLoading(true);
      // const response = await fetch(`${API_URL}/view-record/${recordId}`, {
      const response = await fetch(
        `https://mha-server-latest.onrender.com/view-record/${recordId}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      const data = await response.json();
      setIsLoading(false);
      setRecord(data);
    } catch (e) {
      console.log(e);
      Alert.alert("Failed to fetch record");
      setIsLoading(false);
    }
  };

  // update record
  const updateRecord = async () => {
    try {
      setIsLoading(true);
      // const response = await fetch(`${API_URL}/update-record/${recordId}`, {
      const response = await fetch(
        `https://mha-server-latest.onrender.com/update-record/${recordId}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(record),
        }
      );
      const data = await response.json();

      if (response.ok) {
        Alert.alert("Record updated successfully");
        setIsLoading(false);
        navigation.goBack(); // navigate back to the list of records
      } else {
        Alert.alert("Error", data.message);
        setIsLoading(false);
      }
    } catch (e) {
      console.log("Error", e);
      setIsLoading(false);
      Alert.alert("Failed to update record");
    }
  };

  useEffect(() => {
    fetchRecord();
  }, []);

  return (
    <LinearGradient
      colors={["#fce7f3", "#f0e5ff"]}
      useAngle={true}
      angle={45}
      angleCenter={{ x: 0.5, y: 0.5 }}
      style={styles.container}
    >
      <SafeAreaView>
        {isLoading ? (
          <ActivityIndicator size={"large"} />
        ) : (
          <View>
            <Text style={styles.title}>Update Record</Text>
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Title:</Text>
              <AppTextInput
                style={styles.input}
                value={record.title}
                onChangeText={(text) => setRecord({ ...record, title: text })}
              />
              <Text style={styles.inputLabel}>Type:</Text>
              <AppTextInput
                style={styles.input}
                value={record.type}
                onChangeText={(text) => setRecord({ ...record, type: text })}
              />
              <Text style={styles.inputLabel}>Description:</Text>
              <AppTextInput
                style={styles.input}
                value={record.description}
                multiline
                onChangeText={(text) =>
                  setRecord({ ...record, description: text })
                }
              />
              <Text style={styles.inputLabel}>Notes:</Text>
              <AppTextInput
                style={styles.input}
                value={record.notes}
                multiline
                onChangeText={(text) => setRecord({ ...record, notes: text })}
              />
            </View>
            <TouchableOpacity style={styles.button} onPress={updateRecord}>
              <Text style={styles.buttonText}>Update</Text>
            </TouchableOpacity>
          </View>
        )}
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bg200,
    padding: SIZES.medium,
  },

  title: {
    fontSize: SIZES.xLarge,
    fontWeight: "bold",
    color: COLORS.bluish,
    marginBottom: SIZES.large,
  },
  inputContainer: {
    marginBottom: SIZES.large,
    backgroundColor: COLORS.lightWhite,
    borderWidth: 1,
    borderRadius: SIZES.small,
    borderStyle: "dotted",
    padding: 10,
  },
  inputLabel: {
    fontSize: SIZES.large,
    fontWeight: "bold",
    color: "green",
  },
  input: {
    fontSize: SIZES.medium,
    color: COLORS.text200,
    borderWidth: 1,
    borderColor: COLORS.gray,
    borderRadius: SIZES.small,
    padding: SIZES.small,
    marginBottom: SIZES.medium,
  },
  button: {
    ...SHADOWS.small,
    backgroundColor: COLORS.bluish,
    padding: SIZES.small,
    borderRadius: SIZES.xSmall,
  },
  buttonText: {
    color: COLORS.white,
    textAlign: "center",
  },
});
export default UpdateRecord;
