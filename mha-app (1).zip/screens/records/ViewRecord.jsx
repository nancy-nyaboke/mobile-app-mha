import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Dimensions,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { COLORS, SHADOWS, SIZES } from "../../constants";
import { useFocusEffect } from "@react-navigation/native";
import { getUserInfo } from "../../utils/utils";

const { height } = Dimensions.get("window");

function ViewRecord({ navigation, route }) {
  const { recordId } = route.params;
  const [isLoading, setIsLoading] = useState(false);
  const [record, setRecord] = useState("");
  const [loggedInUserId, setLoggedInUserId] = useState(null);

  // fetch record details
  const fetchRecord = async () => {
    try {
      setIsLoading(true);
      // const response = await fetch(`${API_URL}/view-record/${recordId}`, {
      const response = await fetch(
        `https://mha-server-latest.onrender.com/view-record/${recordId}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      const data = await response.json();
      setIsLoading(false);
      setRecord(data);
    } catch (e) {
      console.log(e);
      Alert.alert("Failed to fetch record");
      setIsLoading(false);
    }
  };

  // delete record
  const deleteRecord = async (recordId) => {
    // get user confirmation
    Alert.alert(
      "Confirm Delete",
      "Are you sure you want to delete this record?",
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Delete",
          onPress: async () => {
            try {
              setIsLoading(true);
              // const response = await fetch(`${API_URL}/delete-record/${recordId}`, {
              const response = await fetch(
                `https://mha-server-latest.onrender.com/delete-record/${recordId}`,
                {
                  method: "DELETE",
                  headers: {
                    "Content-Type": "application/json",
                  },
                }
              );
              const data = await response.json();

              if (response.ok) {
                Alert.alert(data.message);
                setIsLoading(false);
                navigation.goBack(); // navigate back to the list of records
              } else {
                Alert.alert("Error", data.message);
                setIsLoading(false);
              }
            } catch (e) {
              console.log("Error", e);
              setIsLoading(false);
              Alert.alert("Failed to delete record");
            }
          },
        },
      ]
    );
  };

  useFocusEffect(
    useCallback(() => {
      fetchRecord();
      getUserInfo().then((data) => {
        setLoggedInUserId(data.userId);
      });
    }, [])
  );

  return (
    <SafeAreaView style={styles.container}>
      {isLoading ? (
        <ActivityIndicator size={"large"} />
      ) : (
        <View>
          <Text style={styles.title}>Record Details</Text>
          <View style={styles.detailsContainer}>
            <Text style={styles.recordDetails}>
              <Text style={styles.detailHeading}>Title:</Text> {record.title}
            </Text>
            <Text style={styles.recordDetails}>
              <Text style={styles.detailHeading}>Type:</Text> {record.type}
            </Text>
            <Text style={styles.recordDetails}>
              <Text style={styles.detailHeading}>Description:{"\n"}</Text>
              {record.description}
            </Text>
            <Text style={styles.recordDetails}>
              <Text style={styles.detailHeading}>Notes:</Text> {record.notes}
            </Text>
          </View>
          {record.createdBy === loggedInUserId && (
            <View>
              <TouchableOpacity
                style={styles.button}
                onPress={() =>
                  navigation.navigate("UpdateRecord", { recordId: record._id })
                }
              >
                <Text style={styles.buttonText}>Update</Text>
              </TouchableOpacity>

              {isLoading ? (
                <ActivityIndicator size={"large"} />
              ) : (
                <TouchableOpacity
                  style={[styles.button, styles.deleteButton]}
                  onPress={() => deleteRecord(record._id)}
                >
                  <Text style={styles.buttonText}>Delete</Text>
                </TouchableOpacity>
              )}
            </View>
          )}
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bg200,
    padding: SIZES.medium,
  },
  title: {
    fontSize: SIZES.xLarge,
    fontWeight: "bold",
    color: COLORS.bluish,
    marginBottom: SIZES.large,
  },
  detailHeading: {
    fontSize: SIZES.large,
    fontWeight: "bold",
    color: "green",
  },
  recordDetails: {
    fontSize: SIZES.medium,
    color: COLORS.text200,
  },
  detailsContainer: {
    display: "flex",
    flexDirection: "column",
    gap: SIZES.xxLarge,
    backgroundColor: COLORS.lightWhite,
    borderWidth: 1,
    borderStyle: "dashed",
    borderRadius: SIZES.small,
    padding: SIZES.small,
    minHeight: height / 2,
  },
  button: {
    ...SHADOWS.small,
    backgroundColor: COLORS.bluish2,
    padding: SIZES.small,
    borderRadius: SIZES.xSmall,
    marginTop: SIZES.medium,
  },
  deleteButton: {
    backgroundColor: "#da001c",
  },
  buttonText: {
    color: COLORS.white,
    textAlign: "center",
  },
});

export default ViewRecord;
