import React, {useCallback, useState} from 'react';
import {
    View,
    Text,
    StyleSheet,
    FlatList,
    Alert,
    SafeAreaView,
    ActivityIndicator,
    TouchableOpacity
} from 'react-native';
import {COLORS, SIZES} from '../../constants';
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useFocusEffect } from "@react-navigation/native";
import {API_URL} from "@env";

const HealthRecords = ({navigation}) => {
    const [isLoading, setIsLoading] = useState(false)
    const [healthRecords, setHealthRecords] = useState([])

    const fetchHealthRecords = async () => {
        setIsLoading(true)
        try {
            const token = await AsyncStorage.getItem('userToken')
            // const response = await fetch(`${API_URL}/records`, {
                const response = await fetch(
                    `https://mha-server-latest.onrender.com/records`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                },
            });
            const data = await response.json()
            setIsLoading(false)
            setHealthRecords(data)
        } catch (error) {
            setIsLoading(false);
            Alert.alert('Error fetching records', error.message);
        }
    }

    useFocusEffect(
        useCallback(() => {
            fetchHealthRecords()
        }, [])
    )

    const HealthRecord = ({item}) => {
        return (
            <TouchableOpacity onPress={() => navigation.navigate('ViewRecord', {recordId: item._id})}>
                <View style={styles.recordContainer}>
                    <Text style={styles.recordTitle}>{item.title}</Text>
                    <Text style={styles.recordType}>{item.type}</Text>
                    <Text style={styles.recordDetails}>{item.description}</Text>
                </View>
            </TouchableOpacity>
        )
    }

    return (
        <SafeAreaView style={styles.container}>
            {isLoading ? <ActivityIndicator size={"large"}/> :
                <View>
                    <Text style={styles.title}>Health Records</Text>
                    <TouchableOpacity onPress={() => navigation.navigate('AddRecord')}>
                        <Text style={styles.button}>Add Record</Text>
                    </TouchableOpacity>
                    <FlatList
                        data={healthRecords}
                        renderItem={({item}) => <HealthRecord item={item}/>}
                        keyExtractor={(item) => item?._id}
                    />
                    {healthRecords.length === 0 && <Text>No records found</Text>}
                </View>
            }
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.lightWhite,
        padding: SIZES.medium,
    },
    title: {
        fontSize: SIZES.xLarge,
        fontWeight: 'bold',
        color: COLORS.bluish,
        marginBottom: SIZES.large,
    },
    button: {
        textAlign: "center",
        backgroundColor: COLORS.bluish,
        color: COLORS.white,
        padding: SIZES.medium,
        borderRadius: SIZES.xSmall,
        marginBottom: SIZES.xxLarge
    },

    //records
    recordContainer: {
        backgroundColor: COLORS.gray2,
        height: 150,
        overflow: "hidden",
        padding: SIZES.medium,
        borderRadius: SIZES.xSmall,
        marginBottom: SIZES.medium,
    },
    recordTitle: {
        fontSize: SIZES.large,
        fontWeight: 'bold',
        color: COLORS.bluish
    },
    recordType: {
        fontSize: SIZES.large,
        paddingLeft: SIZES.small,
        fontWeight: 'normal',
        color: 'green',
    },
    recordDetails: {
        fontSize: SIZES.medium,
        color: COLORS.text200,
        paddingLeft: SIZES.small
    },
});

export default HealthRecords;
