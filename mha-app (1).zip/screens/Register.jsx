import {useState} from "react";
import {
    ActivityIndicator,
    SafeAreaView,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

import {COLORS, SIZES} from "../constants";
import AppTextInput from "../components/AppTextInput";
import {Picker} from "@react-native-picker/picker";
import { decodeUserInfo } from "../utils/utils";
import {API_URL} from "@env";

const Register = ({navigation, route}) => {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [role, setRole] = useState('patient')

    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const {setUserToken} = route.params;

     const handleRegister = async () => {
        setError(null);

        if (email === "" || password === "" || confirmPassword === "") {
            setError("Please fill all fields");
            return;
        }
        if (password !== confirmPassword) {
            setError("Passwords do not match");
            return;
        }

        setIsLoading(true);
         try {
            //  const response = await fetch(`${API_URL}/register`, {
                const response = await fetch(
                    `https://mha-server-latest.onrender.com/register`, {
                    method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    name,
                    email,
                    password,
                    role,
                }),
            });

            const data = await response.json();

            if (response.ok) {
                setIsLoading(false);
                setUserToken(data.accessToken);
                const decodedData = await decodeUserInfo(data.accessToken);
                await AsyncStorage.setItem("userInfo", JSON.stringify(decodedData));
            } else {
                setError(data.message || data.errors[0].msg);
                setIsLoading(false);
            }
        } catch (error) {
            console.error(error);
            setError(error.message);
            setIsLoading(false);
        }
    };

    return (
        <SafeAreaView>
            <View style={styles.container}>
                <View
                    style={{
                        alignItems: "center",
                    }}
                >
                    {/*<Text*/}
                    {/*    style={{*/}
                    {/*        padding: SIZES.large,*/}
                    {/*        fontSize: SIZES.xxLarge,*/}
                    {/*        color: COLORS.primary100,*/}
                    {/*        fontWeight: "bold",*/}
                    {/*    }}*/}
                    {/*>*/}
                    {/*    Register*/}
                    {/*</Text>*/}

                    <Text
                        style={{
                            fontSize: SIZES.large,
                            maxWidth: "60%",
                            textAlign: "center",
                        }}
                    >
                        Create your Account
                    </Text>
                </View>

                <View
                    style={{
                        padding: 2,
                        marginTop: 40,
                    }}
                >
                    <Text style={{
                        color: COLORS.primary100,
                        fontWeight: 'bold',
                        fontSize: SIZES.medium,
                    }}>What do you want to do?</Text>
                    <Picker
                        selectedValue={role}
                        onValueChange={(itemValue) => setRole(itemValue)}
                        style={styles.input}
                        >
                        <Picker.Item label="Seek Help" value="patient"/>
                        <Picker.Item label="Provide Expert Advice" value="doctor"/>
                    </Picker>
                    <AppTextInput
                        value={name}
                        onChangeText={setName}
                        placeholder="Name"
                    />
                    <AppTextInput
                        value={email}
                        onChangeText={setEmail}
                        placeholder="Email"
                        type="email"
                    />

                    <AppTextInput
                        value={password}
                        onChangeText={setPassword}
                        placeholder="Password"
                        secureTextEntry={true}
                    />
                    <AppTextInput
                        value={confirmPassword}
                        onChangeText={setConfirmPassword}
                        placeholder="Confirm password"
                        secureTextEntry={true}
                    />
                </View>

                {error && (
                    <Text
                        style={{
                            color: "red",
                            textAlign: "center",
                            fontSize: SIZES.medium,

                            marginVertical: SIZES.small,
                        }}
                    >
                        {error}
                    </Text>
                )}

                <TouchableOpacity
                    style={{
                        padding: SIZES.large,
                        backgroundColor: COLORS.primary100,
                        marginVertical: SIZES.small * 3,
                        borderRadius: SIZES.small,
                        shadowColor: COLORS.primary100,
                        shadowOffset: {
                            width: 0,
                            height: SIZES.small,
                        },
                        shadowOpacity: 0.3,
                        shadowRadius: SIZES.small,
                    }}
                    onPress={handleRegister}
                >
                    <Text
                        style={{
                            color: "white",
                            textAlign: "center",
                            fontSize: SIZES.large,
                        }}
                    >
                        {isLoading ? <ActivityIndicator size={"large"}/> : "Register"}
                    </Text>
                </TouchableOpacity>
                <TouchableOpacity
                    onPress={() => navigation.navigate("Login")}
                    style={{
                        padding: SIZES.small,
                    }}
                >
                    <Text
                        style={{
                            color: COLORS.text100,
                            textAlign: "center",
                            fontSize: SIZES.medium,
                        }}
                    >
                        Already have an account
                    </Text>
                </TouchableOpacity>
            </View>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        display: "flex",
        backgroundColor: "#fff",
        height: "100%",
        padding: 20,
    },
    input: {
        height: 40,
        width: "100%",
        marginBottom: 12,
        borderWidth: 1,
        padding: 10,
        color: COLORS.accent200,
        backgroundColor: COLORS.bg200
    },
});

export default Register;
