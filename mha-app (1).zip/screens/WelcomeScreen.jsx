import {Dimensions, ImageBackground, SafeAreaView, StyleSheet, Text, TouchableOpacity, View} from "react-native";
import {LinearGradient} from "expo-linear-gradient";
import {COLORS, SHADOWS, SIZES} from "../constants";

const {height, width} = Dimensions.get('window');

const WelcomeScreen = ({navigation, route}) => {
    const {userToken} = route.params;

    return (<SafeAreaView style={styles.container}>
        <ImageBackground
            source={require('../assets/doctors.png')}
            style={styles.image}
            resizeMode="cover"
        />

        <LinearGradient colors={[COLORS.accent100, COLORS.accent200]} useAngle={true} angle={45}
                        angleCenter={{x: 0.5, y: 0.5}} style={styles.textContainer}>
            <View style={{
                paddingBottom: 36, rowGap: 12, borderBottomWidth: 1, borderBottomColor: COLORS.bg100,
            }}>
                <Text style={{
                    fontSize: SIZES.xxLarge, fontWeight: "bold", // color: COLORS.bg100,
                }}> Your Quick Doctor <Text style={{
                    fontSize: SIZES.xxLarge, fontWeight: "bold", color: COLORS.bg100,
                }}> 🫰🏼 </Text></Text>
                <Text style={{
                    fontSize: SIZES.large, color: COLORS.bg100,
                }}>Your <Text style={{
                    color: COLORS.primary100,
                }}> health </Text> is our priority</Text>
            </View>

            {/* Login / Register Buttons */}
            <View style={{
                flexDirection: 'row', justifyContent: 'space-between', width: '100%', padding: 50, marginTop: 40
            }}>

                <TouchableOpacity onPress={() => navigation.navigate('Login')}>
                    <Text style={{...styles.button, backgroundColor: COLORS.primary100}}>Login</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={() => navigation.navigate('Register')}>
                    <Text style={styles.button}>Register</Text>
                </TouchableOpacity>

            </View>

        </LinearGradient>

    </SafeAreaView>);
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        width: '100%',
    },
    textContainer: {
        flex: 1, // justifyContent: 'center',
        alignItems: 'center',
        width: '100%',
        padding: 12,
        paddingTop: 32
    },
    image: {
        backgroundColor: 'blue',
        height: height / 2.5,
        width: width
    },
    button: {
        padding: 12,
        borderRadius: 12,
        fontSize: SIZES.large,
        color: COLORS.bg100,
        borderWidth: 1,
        borderColor: COLORS.primary100,
        textAlign: "center",
        width: 100,
    },
})
export default WelcomeScreen;
