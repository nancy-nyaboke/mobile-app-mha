import React, { useState, useCallback, useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import { GiftedChat } from 'react-native-gifted-chat';
import { COLORS } from '../constants';

const CommunicationHub = () => {
    const [messages, setMessages] = useState([]);

    useEffect(() => {
        // Fetch previous chat messages from the server
        const fetchMessages = async () => {
            const fetchedMessages = [
                {
                    _id: 1,
                    text: 'Hello, how can I assist you today?',
                    createdAt: new Date(),
                    user: {
                        _id: 2,
                        name: 'Healthcare Provider',
                        avatar: 'https://github.com/james',
                    },
                },
            ];
            setMessages(fetchedMessages);
        };

        fetchMessages();
    }, []);

    const onSend = useCallback((newMessages = []) => {
        setMessages((previousMessages) =>
            GiftedChat.append(previousMessages, newMessages)
        );

        // Send new messages to the server (replace with actual implementation)
    }, []);

    return (
        <View style={styles.container}>
            <GiftedChat
                messages={messages}
                onSend={(newMessages) => onSend(newMessages)}
                user={{
                    _id: 1,
                    name: 'John Doe',
                    avatar: 'https://github.com/john',
                }}
                messageStyle={{
                    backgroundColor: COLORS.gray2,
                }}
                textStyle={{
                    color: COLORS.text200,
                }}
                renderUsernameOnMessage={true}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.lightWhite,
    },
});

export default CommunicationHub;
