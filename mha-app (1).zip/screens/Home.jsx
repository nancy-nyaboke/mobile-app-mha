import React, {useEffect, useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity, Image, Dimensions, ScrollView} from 'react-native';
import {COLORS, SIZES} from '../constants';
import {LinearGradient} from "expo-linear-gradient";
import {getUserInfo} from "../utils/utils";

const {height, width} = Dimensions.get('window');

const patientHealthTips = [
    "Drink at least 8 glasses of water a day.",
    "Get at least 8 hours of sleep every night.",
    "Eat a balanced diet rich in fruits and vegetables.",
    "Exercise for at least 30 minutes a day.",
    "Avoid processed foods and sugary drinks.",
    "Limit your intake of alcohol and avoid smoking.",
    "Practice good hygiene to prevent infections.",
    "Regularly check your blood pressure and cholesterol levels.",
    "Take prescribed medications as directed by your doctor.",
    "Keep up with regular check-ups and screenings."
];

const doctorHealthTips = [
    "Stay up-to-date with the latest medical research and guidelines.",
    "Prioritize effective communication with patients and their families.",
    "Maintain a work-life balance to prevent burnout.",
    "Remember to take regular breaks during your shifts.",
    "Continuously expand your medical knowledge through continuing education.",
    "Practice empathy and understanding with your patients.",
    "Keep your workspace clean and organized.",
    "Ensure patient confidentiality and privacy.",
    "Collaborate with other healthcare professionals for better patient outcomes.",
    "Take care of your own health and well-being too."
];

const Home = ({navigation}) => {
    const [userName, setUserName] = useState(null);
    const [userRole, setUserRole] = useState(null);

    const getGreeting = () => {
        const currentHour = new Date().getHours()
        if (currentHour < 12) {
            return 'Good Morning ⛅';
        } else if (currentHour < 18) {
            return 'Good Afternoon ☀️'
        } else {
            return 'Good Evening 🌙';
        }
    };

    useEffect(() => {
        getUserInfo().then((data) => {
            if (data) {
                setUserRole(data.role)
                setUserName(data.userName)
            }
        })
    }, []);

    const renderHealthTips = () => {
        const tips = userRole === 'patient' ? patientHealthTips : doctorHealthTips;

        return (
            <LinearGradient colors={['#e3c6d6', '#f0e5ff']} useAngle={true} angle={45} angleCenter={{x: 0.5, y: 0.5}}
                            style={{borderRadius: SIZES.small}}>
                <View style={styles.healthTipsContainer}>
                    <Text style={styles.healthTipsTitle}>Healthy Tips</Text>
                    <ScrollView>
                        {tips.map((tip, index) => (
                            <View key={index} style={styles.tipContainer}>
                                <Text style={styles.tipText}>{tip}</Text>
                            </View>
                        ))}
                    </ScrollView>
                </View>
            </LinearGradient>
        );
    };

    return (
        <ScrollView style={styles.container}>
            <View style={styles.headerContainer}>
                <Text style={styles.headerTitle}>{getGreeting()} {userName && userName.split(' ')[0]}</Text>
                <Image
                    source={require('../assets/doctors.png')}
                    style={styles.avatar}
                />
            </View>

            <View style={styles.quickAccessContainer}>
                {userRole === 'doctor' &&
                    <TouchableOpacity style={styles.quickAccessButton} onPress={() => navigation.navigate('Records')}>
                        <Text style={styles.quickAccessButtonText}>Health Records</Text>
                    </TouchableOpacity>
                }
                <TouchableOpacity style={styles.quickAccessButton} onPress={() => navigation.navigate('Chat')}>
                    <Text style={styles.quickAccessButtonText}>{userRole === 'doctor' ? 'Follow Up' : 'Ask'}</Text>
                </TouchableOpacity>
            </View>

            {/* Health tips */}
            {renderHealthTips()}
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.bg200,
        padding: SIZES.large,
    },
    headerContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: SIZES.large,
    },
    headerTitle: {
        fontSize: SIZES.large,
        fontWeight: 'bold',
        color: COLORS.text100,
    },
    avatar: {
        width: 60,
        height: 60,
        borderRadius: 50,
    },
    quickAccessContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: SIZES.medium,
    },
    quickAccessButton: {
        backgroundColor: COLORS.green,
        paddingVertical: SIZES.xxLarge,
        paddingHorizontal: SIZES.medium,
        borderRadius: SIZES.xSmall,
        width: '48%',
    },
    quickAccessButtonText: {
        color: COLORS.white,
        fontWeight: 'bold',
        textAlign: 'center',
    },
    healthTipsContainer: {
        // backgroundColor: COLORS.gray2,
        borderWidth: 1,
        borderStyle: "dashed",
        padding: SIZES.medium,
        borderRadius: SIZES.xSmall,
        height: height / 1.75
    },
    healthTipsTitle: {
        fontSize: SIZES.medium,
        fontWeight: 'bold',
        color: COLORS.bluish,
        marginBottom: SIZES.medium,
    },
    tipContainer: {
        marginBottom: SIZES.medium,
        padding: SIZES.small,
        backgroundColor: COLORS.white,
        borderRadius: SIZES.small,
        minHeight: 65
    },
    tipText: {
        color: COLORS.text100,
    },
});
export default Home;
