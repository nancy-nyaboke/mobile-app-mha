import AsyncStorage from '@react-native-async-storage/async-storage';
import base64 from 'base-64';

export const getUserInfo = async () => {
    const userInfo = await AsyncStorage.getItem('userInfo');
    return JSON.parse(userInfo) || null;
}

export const decodeUserInfo = async (token) => {
    if (!token) return null;

    const decodeJwtToken = (token) => {
        const [header, payload, signature] = token.split('.');
        return JSON.parse(base64.decode(payload));
    };

    try {
        const decoded = decodeJwtToken(token);
        return {
            token,
            role: decoded.role,
            userId: decoded.userId,
            userName: decoded.userName,
            userEmail: decoded.email,
        };
    } catch (e) {
        console.log(e);
        return null;
    }
};
