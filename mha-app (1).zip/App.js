import {useEffect, useState} from "react";
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

import {COLORS} from "./constants";
import WelcomeScreen from "./screens/WelcomeScreen";
import SplashScreen from "./screens/Splash";
import Login from "./screens/Login";
import Register from "./screens/Register";
import AddRecord from "./screens/records/AddRecord";
import UpdateRecord from "./screens/records/UpdateRecord";
import ViewRecord from "./screens/records/ViewRecord";

import TabNavigator from "./components/TabNavigator";
import {getUserInfo} from "./utils/utils";

const Stack = createNativeStackNavigator();

const App = () => {
    const [userToken, setUserToken] = useState(null)
    const [isLoading, setIsLoading] = useState(false)

    useEffect(() => {
        getUserInfo().then((data) => {
            if (data) {
                setUserToken(data.token)
            }
        })
    }, [])

    if (isLoading) {
        return <SplashScreen/>;
    }

    return (
        <NavigationContainer>
            <Stack.Navigator
                screenOptions={{
                    headerShown: true,
                    headerStyle: {
                        backgroundColor: COLORS.primary100,
                    },
                    headerTintColor: 'white',
                    headerTitleStyle: {
                        fontWeight: 'bold',
                    },
                    headerTitleAlign: 'center',
                }}
            >
                {userToken === null ? (
                    <>
                        <Stack.Screen name="Mobile Health Assitant" component={WelcomeScreen}
                                      initialParams={{setUserToken}}/>
                        <Stack.Screen name="Login" component={Login} initialParams={{setUserToken}}/>
                        <Stack.Screen name="Register" component={Register} initialParams={{setUserToken}}/>
                    </>
                ) : (
                    <>
                        <Stack.Screen name="MH Assistant" component={TabNavigator}
                                      initialParams={{setUserToken}}/>
                        <Stack.Screen name="ViewRecord" component={ViewRecord}/>
                        <Stack.Screen name="AddRecord" component={AddRecord}/>
                        <Stack.Screen name="UpdateRecord" component={UpdateRecord}/>
                    </>
                )
                }
            </Stack.Navigator>
        </NavigationContainer>
    );
};

export default App;
