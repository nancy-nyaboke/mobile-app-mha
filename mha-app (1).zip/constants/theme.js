const COLORS = {
    primary100: "#FF4081",
    primary10: "#da001c",
    primary200: "#ff79b0",
    primary300: "#ffe4ff",
    accent100: "#00E5FF",
    accent200: "#00829b",
    text100: "#333333",
    text200: "#5c5c5c",
    bg100: "#F5F5F5",
    bg200: "#ebebeb",
    bg300: "#c2c2c2",

    bluish: "#312651",
    bluish2: "#444262",

    gray: "#83829A",
    gray2: "#C1C0C8",

    white: "#F3F4F8",
    green: "#58af58",

    lightWhite: "#FAFAFC",
};




const SIZES = {
    xSmall: 10,
    small: 12,
    medium: 16,
    large: 20,
    xLarge: 24,
    xxLarge: 32,
};

const SHADOWS = {
    small: {
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 2,
    },
    medium: {
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 5.84,
        elevation: 5,
    },
};

export {COLORS, SIZES, SHADOWS};
