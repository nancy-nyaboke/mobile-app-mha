import { COLORS, FONT, SIZES, SHADOWS } from "./theme";

export { COLORS, FONT, SIZES, SHADOWS };
